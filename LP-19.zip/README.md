# Automatic File Organizer & Backup System

**College DevOps Project**  
**Team No:** 19  
**Student Roll Nos:**
- `24P61A67I8`
- `24P61A67I9`
- `24P61A67J0`

---

## 1. Project Description

The **Automatic File Organizer** is a lightweight, reliable, and modular Python application designed to declutter directories by automatically classifying and organizing files into designated category folders based on their file extensions.

It is engineered with a strict safety-first approach:
- **No Overwriting:** Existing files are never replaced; name collisions are resolved sequentially (e.g., `report.pdf` $\rightarrow$ `report_1.pdf` $\rightarrow$ `report_2.pdf`).
- **No Accidental Deletions:** Files are relocated safely using atomic filesystem operations.
- **Fault-Tolerant & Resilient:** If an error occurs while moving a specific file (e.g., due to file locks or permissions), the error is logged and the program continues processing all remaining files without crashing.
- **Comprehensive Logging:** Every phase (start, directory scan, files detected, files moved, duplicate handling, errors, and completion) is logged to both console and a log file.

---

## 2. Key Features

- **Configurable Source Directory:** Organize any target directory via command-line arguments or use the default `data/input/`.
- **Extension-Based Classification:** Identifies file types case-insensitively using an external `config/categories.json` configuration file.
- **Dynamic Category Folder Creation:** Generates target folders on-the-fly only when matching files are detected.
- **Safe Duplicate Handling:** Automatically detects filename collisions in target folders and appends incremental suffixes (`_1`, `_2`, ...).
- **Subdirectory Isolation:** Only organizes loose files directly in the source directory; previously created category subdirectories are never recursed into.
- **Modular Architecture:** Logic is cleanly divided into separate modules for classification, duplicate resolution, moving, logging, and application entry points.
- **Comprehensive PyTest Suite:** Thorough unit and integration test coverage across all components.

---

## 3. Initial File Categories

The application classifies files into the following initial categories:

| Category | Extensions Handled |
| :--- | :--- |
| **Images** | `jpg`, `jpeg`, `png`, `gif`, `webp` |
| **Documents** | `doc`, `docx`, `txt`, `odt` |
| **PDFs** | `pdf` |
| **Videos** | `mp4`, `avi`, `mkv`, `mov` |
| **Audio** | `mp3`, `wav`, `flac` |
| **Source_Code** | `py`, `java`, `c`, cpp`, `js`, `html`, `css` |
| **Archives** | `zip`, `rar`, `7z` |
| **Others** | All other unsupported or missing extensions |

---

## 4. Project Structure

```
LP-19/
│
├── config/
│   └── categories.json          # Extension-to-category mapping configuration
│
├── data/
│   ├── input/                   # Default source directory for loose files
│   ├── web_input/               # Controlled staging directory for web uploads
│   └── web_backup/              # Backup directory for web operations
│
├── logs/
│   ├── organizer.log            # Application runtime log file
│   └── web_app.log              # Web interface runtime log file
│
├── src/
│   ├── __init__.py              # Package initializer and component exports
│   ├── classifier.py            # File classification logic & config loading
│   ├── duplicate_handler.py     # Non-overwriting duplicate name resolution
│   ├── mover.py                 # Safe file moving & per-file error handling
│   ├── logger.py                # Structured console & file logging
│   ├── organizer.py             # Core FileOrganizer orchestration class
│   ├── main.py                  # CLI application entry point
│   ├── backup.py                # Standalone backup module (Stage 2)
│   └── web_app.py               # Flask web dashboard application (Stage W1)
│
├── templates/
│   └── index.html               # Web dashboard HTML/CSS user interface
│
├── tests/
│   ├── __init__.py              # Test package initializer
│   ├── test_classifier.py       # Unit tests for extension classification
│   ├── test_duplicate_handler.py# Unit tests for duplicate renaming
│   ├── test_mover.py            # Unit tests for file movement & permissions
│   ├── test_organizer.py        # End-to-end integration & resilience tests
│   ├── test_backup.py           # Unit tests for backup module
│   ├── test_cli.py              # Unit tests for CLI entry point
│   └── test_web_app.py          # PyTest suite for Flask web routes & uploads
│
├── Dockerfile                   # Multi-stage containerization recipe
├── Jenkinsfile                  # CI/CD declarative pipeline definition
├── .gitignore                   # Git ignore rules for virtualenvs, caches, logs
├── README.md                    # Project documentation
├── requirements.txt             # Runtime dependencies (Flask)
└── requirements-dev.txt         # Development/testing dependencies (pytest)
```

---

## 5. Requirements

- **Python Version:** Python 3.10 or newer (tested on Python 3.13)
- **Runtime Dependencies:** Python Standard Library only (`pathlib`, `shutil`, `json`, `logging`, `argparse`)
- **Testing Dependencies:** `pytest>=7.0`

---

## 6. Installation Steps

### 1. Clone the Repository
```powershell
git clone <repository-url>
cd LP-19
```

### 2. (Optional but Recommended) Create a Virtual Environment
```powershell
python -m venv .venv
.venv\Scripts\activate
```

### 3. Install Development Dependencies (PyTest)
```powershell
python -m pip install -r requirements-dev.txt
```

## 7. How to Run the Application

### Option A: Organize Only (Without Backup)
```powershell
python src/main.py --source "data/input"
```
*(Organizes files directly into category folders without creating backups).*

### Option B: Organize With Automatic Backup
```powershell
python src/main.py --source "data/input" --backup
```
*(Creates a safe copy of loose files in `backup/` first; proceeds to organize only if backup succeeds).*

### Option C: Custom Source & Backup Directories
```powershell
python src/main.py --source "data/input" --backup --backup-dir "custom_backup"
```

### View CLI Help
```powershell
python src/main.py --help
```

---

## 8. Example Input and Output

### Example Input
Place any loose files into `data/input/`:
```
data/input/
├── vacation.jpg
├── notes.txt
├── invoice.pdf
├── script.py
├── movie.mp4
├── song.mp3
├── backup.zip
└── mystery.xyz
```

### Running the Organizer
```powershell
python src/main.py
```

### Terminal Output
```
2026-10-13 21:22:39 | INFO    | === Automatic File Organizer Started ===
2026-10-13 21:22:39 | INFO    | Scanning directory: C:\Users\...\LP-19\data\input
2026-10-13 21:22:39 | INFO    | Files detected: 8 loose file(s)
2026-10-13 21:22:39 | INFO    | File successfully moved: 'backup.zip' -> 'Archives/backup.zip'
2026-10-13 21:22:39 | INFO    | File successfully moved: 'invoice.pdf' -> 'PDFs/invoice.pdf'
2026-10-13 21:22:39 | INFO    | File successfully moved: 'movie.mp4' -> 'Videos/movie.mp4'
2026-10-13 21:22:39 | INFO    | File successfully moved: 'mystery.xyz' -> 'Others/mystery.xyz'
2026-10-13 21:22:39 | INFO    | File successfully moved: 'notes.txt' -> 'Documents/notes.txt'
2026-10-13 21:22:39 | INFO    | File successfully moved: 'script.py' -> 'Source_Code/script.py'
2026-10-13 21:22:39 | INFO    | File successfully moved: 'song.mp3' -> 'Audio/song.mp3'
2026-10-13 21:22:39 | INFO    | File successfully moved: 'vacation.jpg' -> 'Images/vacation.jpg'
2026-10-13 21:22:39 | INFO    | === Application Completed | Moved: 8, Duplicates Renamed: 0, Failed: 0 ===

=======================================================
      Automatic File Organizer System (Team 19)
=======================================================
Target Directory : C:\Users\...\LP-19\data\input
Config File      : C:\Users\...\LP-19\config\categories.json
Log File         : C:\Users\...\LP-19\logs\organizer.log
=======================================================

==========================================
      File Organization Summary
==========================================
Total files organized: 8 into 8 category/categories:

  [Archives] (1 files)
    - backup.zip
  [Audio] (1 files)
    - song.mp3
  [Documents] (1 files)
    - notes.txt
  [Images] (1 files)
    - vacation.jpg
  [Others] (1 files)
    - mystery.xyz
  [PDFs] (1 files)
    - invoice.pdf
  [Source_Code] (1 files)
    - script.py
  [Videos] (1 files)
    - movie.mp4
==========================================
```

### Resulting Directory Structure
```
data/input/
├── Archives/
│   └── backup.zip
├── Audio/
│   └── song.mp3
├── Documents/
│   └── notes.txt
├── Images/
│   └── vacation.jpg
├── Others/
│   └── mystery.xyz
├── PDFs/
│   └── invoice.pdf
├── Source_Code/
│   └── script.py
└── Videos/
    └── movie.mp4
```

### Duplicate Handling in Action
If a second `invoice.pdf` is placed into `data/input/` and the organizer is rerun:
```
2026-10-13 21:23:07 | INFO    | Duplicate filename handled: 'invoice.pdf' renamed to 'invoice_1.pdf' in 'PDFs/'
2026-10-13 21:23:07 | INFO    | File successfully moved: 'invoice.pdf' -> 'PDFs/invoice_1.pdf'
```
Resulting files inside `data/input/PDFs/`:
```
data/input/PDFs/
├── invoice.pdf     (original file preserved)
└── invoice_1.pdf   (newly added file safely renamed)
```

---

## 9. Running Automated Tests

All tests are implemented using `pytest` and execute against isolated temporary folders (`tmp_path`), ensuring zero interference with real files.

### Run All Tests (99 Total Tests)
```powershell
python -m pytest -v
```

### Run Web Interface Tests
```powershell
python -m pytest tests/test_web_app.py -v
```

### Run Only Core Organizer Tests
```powershell
python -m pytest tests/test_classifier.py tests/test_duplicate_handler.py tests/test_mover.py tests/test_organizer.py -v
```

---

## 10. Stage W1: Web Interface (Flask Dashboard)

The application includes an intuitive web interface built with Flask on top of the existing organizer and backup core modules. It operates strictly within controlled staging and backup directories (`data/web_input/` and `data/web_backup/`) to prevent unauthorized or arbitrary file system access.

### Key Capabilities
- **File Upload & Staging:** Upload single or multiple files directly from the browser into `data/web_input/`.
- **Safe Duplicate Handling:** Uses `resolve_duplicate_path` to guarantee that uploading a duplicate file never overwrites an existing staged file (e.g., `report.pdf` $\rightarrow$ `report_1.pdf`).
- **File Name Sanitization:** Sanitizes all uploaded filenames with `secure_filename` to block directory traversal attacks (`../`).
- **Organize Staged Files:** Categorizes loose files inside `data/web_input/` into subdirectories (`Documents/`, `Images/`, etc.).
- **Backup & Organize:** Backs up loose files into `data/web_backup/` first, and aborts organization if any backup failure occurs.
- **Live Summary & Logs:** Real-time visibility of operations, category counts, and application logs.

### Starting the Web Server
Launch the Flask web backend from the project root:
```powershell
python -m src.web_app
```

Then open your browser and navigate to:
```
http://127.0.0.1:5000/
```

### Web Routes & API Endpoints
| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/` | Web dashboard displaying staged files, categories, latest results, and logs |
| `POST` | `/upload` | Secure file upload form handling single/multiple files |
| `POST` | `/organize` | Triggers file classification and movement into category folders |
| `POST` | `/backup` | Triggers file backup followed by organization |
| `GET` | `/results` | JSON summary of the most recent operation |
| `GET` | `/logs` | View recent application log entries as plain text |

---

## 11. Stage 3: Docker Containerization

The application is fully containerized using a lightweight, secure Docker setup (`python:3.12-slim`).

### Why Use Docker Volume Mounts?
Instead of copying host files into the Docker image during build, Docker **volume mounts** (`-v` or `--volume`) are used:
1. **Separation of Code & Data:** The container image remains a generic, reusable artifact containing only the code and configuration (~43 MB content size).
2. **Data Persistence:** When a container stops and is removed (`--rm`), all organized files, backups, and logs remain saved directly on your host machine.
3. **Security:** User documents are never baked into container image layers or leaked into container registries.

### Docker Prerequisites
- [Docker Desktop](https://www.docker.com/products/docker-desktop/) installed and running.
- Linux container mode active (default on Windows WSL2).

### 1. Build the Docker Image
From the project root:
```powershell
docker build -t lp19-file-organizer .
```

### 2. Run File Organizer in Docker (Without Backup)
Organizes files in `data/input/` on the host into category subfolders:
```powershell
docker run --rm `
  -v "${PWD}/data/input:/app/data/input" `
  -v "${PWD}/logs:/app/logs" `
  lp19-file-organizer
```

### 3. Run File Organizer in Docker (With Backup)
Creates backups in `backup/` on the host, then organizes `data/input/`:
```powershell
docker run --rm `
  -v "${PWD}/data/input:/app/data/input" `
  -v "${PWD}/backup:/app/backup" `
  -v "${PWD}/logs:/app/logs" `
  lp19-file-organizer --backup
```

### 4. Running from Command Prompt (CMD)
In standard Windows Command Prompt (`cmd.exe`), replace `${PWD}` with `%cd%`:
```cmd
docker run --rm -v "%cd%/data/input:/app/data/input" -v "%cd%/backup:/app/backup" -v "%cd%/logs:/app/logs" lp19-file-organizer --backup
```

### 5. Running from Linux / macOS (Bash / Zsh)
```bash
docker run --rm \
  -v "$(pwd)/data/input:/app/data/input" \
  -v "$(pwd)/backup:/app/backup" \
  -v "$(pwd)/logs:/app/logs" \
  lp19-file-organizer --backup
```

### Volume Mount Map
| Host Path | Container Path | Purpose |
| :--- | :--- | :--- |
| `${PWD}/data/input` | `/app/data/input` | Directory containing loose files to organize |
| `${PWD}/backup` | `/app/backup` | Persistent storage for file copies prior to move |
| `${PWD}/logs` | `/app/logs` | Persistent log files (`organizer.log`, `backup.log`) |

---

## 12. Stage 4: Jenkins CI/CD Integration

The repository includes a Declarative [`Jenkinsfile`](file:///C:/Users/vaibh/OneDrive/Desktop/LP-19/Jenkinsfile) automating continuous testing and Docker image creation.

```
Git Push ──► Checkout SCM ──► Env Setup ──► PyTest (87 Tests) ──► Docker Build ──► Container Smoke Test ──► Publish JUnit Report
                                                  │ (Fails build if
                                                  ▼  tests fail)
                                              Pipeline Halted
```

### 1. Jenkins Prerequisites
- **Jenkins Controller/Agent:** Jenkins 2.x+ running (e.g. `http://localhost:8080`).
- **Tools on Agent PATH:** `git`, `python` / `python3`, `pip`, and `docker`.
- **Docker Permissions:** Jenkins service user must have permission to execute Docker commands (`docker.sock` access on Linux or Docker Desktop on Windows).

### 2. Required Jenkins Plugins
Ensure these plugins are installed (**Manage Jenkins** $\rightarrow$ **Plugins**):
- **Pipeline** (`workflow-aggregator`)
- **Git plugin** (`git`)
- **JUnit Plugin** (`junit`)
- **Docker** / **Docker Pipeline**

### 3. Pipeline Configuration Steps in Jenkins UI
1. Open Jenkins at `http://localhost:8080/`.
2. Click **New Item** on the dashboard.
3. Enter item name: `LP19-File-Organizer-Pipeline`.
4. Select **Pipeline** and click **OK**.
5. Scroll down to the **Pipeline** configuration section:
   - **Definition:** Select `Pipeline script from SCM`.
   - **SCM:** Select `Git`.
   - **Repository URL:** Enter your GitHub repository URL (e.g. `https://github.com/DEVOPSCSD/LP-19.git`).
   - **Branch Specifier:** `*/main` (or target branch).
   - **Script Path:** `Jenkinsfile`.
6. Click **Save**.

### 4. How to Run the Pipeline
1. Open the created job (`LP19-File-Organizer-Pipeline`).
2. Click **Build Now** on the left menu.
3. Observe live build progress under **Build History** $\rightarrow$ **Console Output**.

### 5. Expected Pipeline Stages
| Stage | Execution Details |
| :--- | :--- |
| **Stage 1: Checkout** | Clones/checks out the latest commit from the Git repository. |
| **Stage 2: Environment Setup** | Validates Python and Pip versions; installs `requirements.txt` and `requirements-dev.txt`. |
| **Stage 3: Automated Testing** | Runs `pytest -v --junitxml=test-results.xml` across all 87 tests. |
| **Stage 4: Docker Build** | Builds Docker images tagged with `${BUILD_NUMBER}` and `latest`. |
| **Stage 5: Docker Verification** | Verifies image in registry, tests `--help` CLI, and runs a synthetic container volume-mount test. |
| **Post-Build** | Publishes JUnit XML test reports and reports build pass/fail status. |

### 6. Fail-Safe: How Test Failures Stop the Pipeline
If any test in `tests/` fails, `pytest` returns an exit code of `1`. In Jenkins Declarative Pipelines:
1. Stage **Automated Testing** immediately transitions to `FAILED`.
2. Execution halts immediately—Stage 4 (**Docker Build**) and Stage 5 (**Docker Verification**) are **skipped**.
3. No broken Docker image is built or tagged.
4. The post-build `junit` step still publishes the failed test diagnostics for developer debugging.

### 7. Reproducible Docker Image Tagging
Docker images produced by the pipeline are tagged with the specific Jenkins build ID:
- `lp19-file-organizer:${BUILD_NUMBER}` (e.g., `lp19-file-organizer:1`, `lp19-file-organizer:2`)
- `lp19-file-organizer:latest`
This guarantees traceability between the CI build logs and the resulting container artifact.


