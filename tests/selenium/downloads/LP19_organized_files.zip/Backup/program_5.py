print('LP-19 test file')
