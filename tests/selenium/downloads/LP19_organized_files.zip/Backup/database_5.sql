CREATE TABLE test_data (id INTEGER, name TEXT);
